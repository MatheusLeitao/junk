const info  = require("./plans.json")
const vendors = require("./vendors.json")
const Axios = require('axios')
const uuid = require('uuid')
const checkingAccounts = require('./bank-account.json')

const axios = Axios.create({
    baseURL: "https://app.omie.com.br/api/v1",
})

const prepareBody = (call, payload) => {
    return {
        call: call,
        app_key: "2669752996911",
        app_secret: "25f28899b0189e40e7a6fcd8c3c317e8",
        param: [payload]
    }
}


const populatePlans = async () => {
    info.forEach(async (plan, key) => {
        console.log(plan.cabecalho.cDescricao)
        
        plan.intEditar.cCodIntServ = uuid.v4().substring(0,18)
        
        const data = prepareBody('UpsertCadastroServico', plan)
        
        const response = await axios.post('/servicos/servico/', data).catch(
           await handleErrors({ alias: key, url: '/servicos/servico/', data })
        )
        
        if(!!response && response.data !== undefined) console.log(response.data)
    })
}


const handleErrors = async ({ alias, url, data }) => {
    let bind = {}
    
    bind[alias] = setInterval(async () => {
        const response = await axios.post(url, data)
        .then(res => {
            console.log(res.data)
            clearInterval(bind[alias])
        })
        .catch(err => console.log(`Couldn't insert plan ${data.param[0].cabecalho.cDescricao}`))
    }, 2000);
    
}

const populateVendors = async () => {
    vendors.codInt = uuid.v4().substring(0,18)
    const data = prepareBody('IncluirVendedor', vendors)
    const response = await axios.post('/geral/vendedores/', data).catch(err => console.log('method: populateVendors', err.response.data))
    if(!!response.codigo) console.log('Vendedor incluso.')
}

const populateCheckingAccounts = async () => {
    checkingAccounts.cCodCCInt = uuid.v4().substring(0,18)
    const data = prepareBody('IncluirContaCorrente', checkingAccounts)
    const response = await axios.post('/geral/contacorrente/', data).catch(err => console.log('method: populateCheckingAccounts', err.response.data))
    if(!!response.codigo) console.log('Conta corrente inclusa.')
}

const main = async () => {  
    const [...responses] = await Promise.all([
        populateVendors(),
        populateCheckingAccounts(),
        populatePlans()
    ])
}

main()
